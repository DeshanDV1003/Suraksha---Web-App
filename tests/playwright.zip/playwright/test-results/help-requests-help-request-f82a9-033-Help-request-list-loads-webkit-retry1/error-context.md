# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: help-requests\help-requests.spec.ts >> Help Requests >> TC-PW-033: Help request list loads
- Location: e2e\help-requests\help-requests.spec.ts:5:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('help-request-card').or(getByText(/no pending/i)).first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByTestId('help-request-card').or(getByText(/no pending/i)).first()

```

```yaml
- complementary:
  - link "S Suraksha":
    - /url: /
  - navigation:
    - heading "Command Center" [level=2]
    - list:
      - listitem:
        - link "Dashboard":
          - /url: /
      - listitem:
        - link "Live Map":
          - /url: /map
      - listitem:
        - link "Water Monitor":
          - /url: /water-monitor
      - listitem:
        - link "Incidents":
          - /url: /incidents
      - listitem:
        - link "Alerts":
          - /url: /suraksha-alerts
      - listitem:
        - link "Analytics":
          - /url: /reports
      - listitem:
        - link "User Management":
          - /url: /users
    - heading "Resources" [level=2]
    - list:
      - listitem:
        - link "Resources":
          - /url: /resources
      - listitem:
        - link "Relief Camps":
          - /url: /camps
      - listitem:
        - link "Relief Tokens":
          - /url: /tokens
      - listitem:
        - link "Donations":
          - /url: /donations
    - heading "Safety & Support" [level=2]
    - list:
      - listitem:
        - link "Volunteers":
          - /url: /volunteers
      - listitem:
        - link "Task Management":
          - /url: /tasks
      - listitem:
        - link "Help Requests":
          - /url: /help-requests
      - listitem:
        - link "Damage Assessment":
          - /url: /damage-assessment
      - listitem:
        - link "Missing Persons":
          - /url: /missing-persons
      - listitem:
        - link "Safety Roster":
          - /url: /family-safety
      - listitem:
        - link "Psychological Support":
          - /url: /support
      - listitem:
        - link "Public Help Portal":
          - /url: /request-help
      - listitem:
        - link "Public Missing Portal":
          - /url: /missing-portal
    - heading "System" [level=2]
    - list:
      - listitem:
        - link "AI Research":
          - /url: /ai-research
      - listitem:
        - link "Settings":
          - /url: /settings
      - listitem:
        - link "River Mappings":
          - /url: /river-mappings
- banner:
  - button "Toggle Sidebar":
    - img
  - img
  - button "Search or type command..."
  - button "⌘ K"
  - button:
    - img
  - button:
    - img
  - button "PW PW Admin":
    - text: PW PW Admin
    - img
- heading "Help Requests" [level=2]
- navigation:
  - list:
    - listitem:
      - link "Home":
        - /url: /
        - text: Home
        - img
    - listitem: Help Requests
- button "Suraksha Assistant"
```

# Test source

```ts
  1  | import { test, expect } from '../../fixtures/test.fixtures';
  2  | import { HelpRequestsPage } from '../../pages/HelpRequestsPage.pom';
  3  | 
  4  | test.describe('Help Requests', () => {
  5  |   test('TC-PW-033: Help request list loads', async ({ adminPage }) => {
  6  |     const page = new HelpRequestsPage(adminPage);
  7  |     await page.goto();
  8  |     
  9  |     // Either a list of request cards, or the "all clear" empty state
> 10 |     await expect(page.listContainer.or(adminPage.getByText(/no pending/i)).first()).toBeVisible({ timeout: 10000 });
     |                                                                                     ^ Error: expect(locator).toBeVisible() failed
  11 |   });
  12 | 
  13 |   test('TC-PW-034: Status filter works', async ({ adminPage }) => {
  14 |     const page = new HelpRequestsPage(adminPage);
  15 |     await page.goto();
  16 |     
  17 |     const filter = adminPage.locator('select').first();
  18 |     if (await filter.count() > 0) {
  19 |       // Assuming 'PENDING' is a valid option
  20 |       await filter.selectOption({ label: 'PENDING' }).catch(() => filter.selectOption({ index: 1 }));
  21 |       await adminPage.waitForTimeout(500); // Give time for UI to update
  22 |     }
  23 |   });
  24 | });
  25 | 
```