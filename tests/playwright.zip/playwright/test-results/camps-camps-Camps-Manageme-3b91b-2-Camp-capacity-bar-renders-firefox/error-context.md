# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: camps\camps.spec.ts >> Camps Management >> TC-PW-042: Camp capacity bar renders
- Location: e2e\camps\camps.spec.ts:9:7

# Error details

```
Error: page.goto: NS_ERROR_CONNECTION_REFUSED
Call log:
  - navigating to "http://localhost:4173/camps", waiting until "load"

```

# Page snapshot

```yaml
- article [ref=e3]:
  - generic [ref=e6]:
    - heading "Unable to connect" [level=1] [ref=e7]
    - paragraph [ref=e8]:
      - text: Nightly can’t connect to the server at
      - strong [ref=e9]: localhost:4173
    - generic [ref=e10]:
      - heading "What can you do about it?" [level=3] [ref=e11]
      - list [ref=e12]:
        - listitem [ref=e13]: The site could be temporarily unavailable or too busy. Try again in a few moments.
        - listitem [ref=e14]: If you are unable to load any pages, check your computer’s network connection.
        - listitem [ref=e15]: If your computer or network is protected by a firewall or proxy, make sure that Nightly is permitted to access the web.
    - button "Try Again" [ref=e18]
```

# Test source

```ts
  1  | import { test, expect } from '../../fixtures/test.fixtures';
  2  | 
  3  | test.describe('Camps Management', () => {
  4  |   test('TC-PW-041: Camps list loads', async ({ adminPage }) => {
  5  |     await adminPage.goto('/camps');
  6  |     await expect(adminPage.locator('.bg-white').or(adminPage.getByText(/no camps/i)).first()).toBeVisible({ timeout: 10000 });
  7  |   });
  8  | 
  9  |   test('TC-PW-042: Camp capacity bar renders', async ({ adminPage }) => {
> 10 |     await adminPage.goto('/camps');
     |                     ^ Error: page.goto: NS_ERROR_CONNECTION_REFUSED
  11 |     // Usually there's a progress bar element
  12 |     const progressBar = adminPage.locator('.bg-gray-200 > div, progress').first();
  13 |     if (await progressBar.count() > 0) {
  14 |       await expect(progressBar).toBeVisible();
  15 |     }
  16 |   });
  17 | 
  18 |   test('TC-PW-043: Add new camp form', async ({ adminPage }) => {
  19 |     await adminPage.goto('/camps');
  20 |     const addBtn = adminPage.getByRole('button', { name: /add|create/i }).or(adminPage.locator('button').filter({ hasText: /add/i }));
  21 |     
  22 |     if (await addBtn.count() > 0) {
  23 |       await addBtn.first().click();
  24 |       await expect(adminPage.locator('form').filter({ hasText: /camp/i })).toBeVisible();
  25 |     }
  26 |   });
  27 | });
  28 | 
```