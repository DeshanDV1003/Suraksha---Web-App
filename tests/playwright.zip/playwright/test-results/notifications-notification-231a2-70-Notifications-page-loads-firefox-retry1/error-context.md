# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: notifications\notifications.spec.ts >> Notifications >> TC-PW-070: Notifications page loads
- Location: e2e\notifications\notifications.spec.ts:4:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
TimeoutError: page.goto: Timeout 45000ms exceeded.
Call log:
  - navigating to "http://localhost:4173/notifications", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '../../fixtures/test.fixtures';
  2  | 
  3  | test.describe('Notifications', () => {
  4  |   test('TC-PW-070: Notifications page loads', async ({ adminPage }) => {
> 5  |     await adminPage.goto('/notifications');
     |                     ^ TimeoutError: page.goto: Timeout 45000ms exceeded.
  6  |     // .or() matches the union of both sides, so when both are present at once we must
  7  |     // re-apply .first() to the combined locator (not to each side) to keep strict mode happy.
  8  |     const notificationsContent = adminPage.locator('main').locator('.bg-white, .grid').or(adminPage.getByText(/no notifications/i));
  9  |     await expect(notificationsContent.first()).toBeVisible({ timeout: 10000 });
  10 |   });
  11 | 
  12 |   test('TC-PW-071: Mark-as-read interaction', async ({ adminPage }) => {
  13 |     await adminPage.goto('/notifications');
  14 |     const markReadBtn = adminPage.getByRole('button', { name: /mark as read/i }).or(adminPage.locator('button').filter({ hasText: /read/i }));
  15 |     
  16 |     if (await markReadBtn.count() > 0) {
  17 |       await markReadBtn.first().click();
  18 |       // Assume success if no crash and element updates
  19 |       await adminPage.waitForTimeout(500);
  20 |     }
  21 |   });
  22 | });
  23 | 
```