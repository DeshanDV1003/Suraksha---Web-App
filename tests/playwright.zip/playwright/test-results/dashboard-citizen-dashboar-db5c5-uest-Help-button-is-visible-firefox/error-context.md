# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboard\citizen-dashboard.spec.ts >> Dashboard - Citizen >> TC-PW-020: "Request Help" button is visible
- Location: e2e\dashboard\citizen-dashboard.spec.ts:9:7

# Error details

```
Error: page.goto: NS_ERROR_CONNECTION_REFUSED
Call log:
  - navigating to "http://localhost:4173/citizen-home", waiting until "load"

```

# Page snapshot

```yaml
- article [ref=e3]:
  - generic [ref=e6]:
    - heading "Unable to connect" [level=1] [ref=e7]
    - paragraph [ref=e8]:
      - text: Nightly can’t connect to the server at
      - strong [ref=e9]: localhost:4173
    - generic [ref=e10]:
      - heading "What can you do about it?" [level=3] [ref=e11]
      - list [ref=e12]:
        - listitem [ref=e13]: The site could be temporarily unavailable or too busy. Try again in a few moments.
        - listitem [ref=e14]: If you are unable to load any pages, check your computer’s network connection.
        - listitem [ref=e15]: If your computer or network is protected by a firewall or proxy, make sure that Nightly is permitted to access the web.
    - button "Try Again" [ref=e18]
```

# Test source

```ts
  1  | import { test, expect } from '../../fixtures/test.fixtures';
  2  | 
  3  | test.describe('Dashboard - Citizen', () => {
  4  |   test('TC-PW-019: Citizen dashboard loads at /citizen-home', async ({ citizenPage }) => {
  5  |     await citizenPage.goto('/citizen-home');
  6  |     await expect(citizenPage).toHaveURL(/.*citizen-home/);
  7  |   });
  8  | 
  9  |   test('TC-PW-020: "Request Help" button is visible', async ({ citizenPage }) => {
> 10 |     await citizenPage.goto('/citizen-home');
     |                       ^ Error: page.goto: NS_ERROR_CONNECTION_REFUSED
  11 |     const helpBtn = citizenPage.getByRole('button', { name: /request help|i need help/i }).or(citizenPage.locator('a').filter({ hasText: /request help/i }));
  12 |     await expect(helpBtn.first()).toBeVisible();
  13 |   });
  14 | 
  15 |   test('TC-PW-021: Water level widget visible', async ({ citizenPage }) => {
  16 |     await citizenPage.goto('/citizen-home');
  17 |     const waterWidget = citizenPage.locator('.bg-white, .dark\\:bg-gray-800').filter({ hasText: /water|river|level/i });
  18 |     if (await waterWidget.count() > 0) {
  19 |       await expect(waterWidget.first()).toBeVisible();
  20 |     }
  21 |   });
  22 | });
  23 | 
```