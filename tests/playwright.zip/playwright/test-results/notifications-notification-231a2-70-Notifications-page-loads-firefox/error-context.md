# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: notifications\notifications.spec.ts >> Notifications >> TC-PW-070: Notifications page loads
- Location: e2e\notifications\notifications.spec.ts:4:7

# Error details

```
Error: page.goto: NS_ERROR_CONNECTION_REFUSED
Call log:
  - navigating to "http://localhost:4173/notifications", waiting until "load"

```

# Page snapshot

```yaml
- article [ref=e3]:
  - generic [ref=e6]:
    - heading "Unable to connect" [level=1] [ref=e7]
    - paragraph [ref=e8]:
      - text: Nightly can’t connect to the server at
      - strong [ref=e9]: localhost:4173
    - generic [ref=e10]:
      - heading "What can you do about it?" [level=3] [ref=e11]
      - list [ref=e12]:
        - listitem [ref=e13]: The site could be temporarily unavailable or too busy. Try again in a few moments.
        - listitem [ref=e14]: If you are unable to load any pages, check your computer’s network connection.
        - listitem [ref=e15]: If your computer or network is protected by a firewall or proxy, make sure that Nightly is permitted to access the web.
    - button "Try Again" [ref=e18]
```

# Test source

```ts
  1  | import { test, expect } from '../../fixtures/test.fixtures';
  2  | 
  3  | test.describe('Notifications', () => {
  4  |   test('TC-PW-070: Notifications page loads', async ({ adminPage }) => {
> 5  |     await adminPage.goto('/notifications');
     |                     ^ Error: page.goto: NS_ERROR_CONNECTION_REFUSED
  6  |     // .or() matches the union of both sides, so when both are present at once we must
  7  |     // re-apply .first() to the combined locator (not to each side) to keep strict mode happy.
  8  |     const notificationsContent = adminPage.locator('main').locator('.bg-white, .grid').or(adminPage.getByText(/no notifications/i));
  9  |     await expect(notificationsContent.first()).toBeVisible({ timeout: 10000 });
  10 |   });
  11 | 
  12 |   test('TC-PW-071: Mark-as-read interaction', async ({ adminPage }) => {
  13 |     await adminPage.goto('/notifications');
  14 |     const markReadBtn = adminPage.getByRole('button', { name: /mark as read/i }).or(adminPage.locator('button').filter({ hasText: /read/i }));
  15 |     
  16 |     if (await markReadBtn.count() > 0) {
  17 |       await markReadBtn.first().click();
  18 |       // Assume success if no crash and element updates
  19 |       await adminPage.waitForTimeout(500);
  20 |     }
  21 |   });
  22 | });
  23 | 
```