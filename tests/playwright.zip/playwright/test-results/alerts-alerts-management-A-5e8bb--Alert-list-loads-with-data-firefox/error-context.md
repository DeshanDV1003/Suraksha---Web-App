# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: alerts\alerts-management.spec.ts >> Alerts Management >> TC-PW-022: Alert list loads with data
- Location: e2e\alerts\alerts-management.spec.ts:6:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
TimeoutError: page.goto: Timeout 45000ms exceeded.
Call log:
  - navigating to "http://localhost:4173/suraksha-alerts", waiting until "load"

```

# Test source

```ts
  1  | import { Page, Locator } from '@playwright/test';
  2  | 
  3  | export class AlertsPage {
  4  |   readonly page: Page;
  5  |   /** The broadcast composer is an always-visible form for ADMIN/DMC_OFFICER —
  6  |    * there is no "open a dialog" step, unlike most other create-record pages. */
  7  |   readonly alertComposer: Locator;
  8  |   readonly titleInput: Locator;
  9  |   readonly submitButton: Locator;
  10 |   readonly alertList: Locator;
  11 | 
  12 |   constructor(page: Page) {
  13 |     this.page = page;
  14 |     this.alertComposer = page.locator('#alert-composer');
  15 |     this.titleInput = page.getByTestId('alert-title-input');
  16 |     this.submitButton = this.alertComposer.getByRole('button').last();
  17 |     this.alertList = page.getByTestId('alert-card').first();
  18 |   }
  19 | 
  20 |   async goto() {
> 21 |     await this.page.goto('/suraksha-alerts');
     |                     ^ TimeoutError: page.goto: Timeout 45000ms exceeded.
  22 |   }
  23 | }
  24 | 
```