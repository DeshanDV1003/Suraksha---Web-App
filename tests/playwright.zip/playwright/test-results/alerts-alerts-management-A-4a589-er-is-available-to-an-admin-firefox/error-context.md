# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: alerts\alerts-management.spec.ts >> Alerts Management >> TC-PW-023: New-alert broadcast composer is available to an admin
- Location: e2e\alerts\alerts-management.spec.ts:13:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator:  getByTestId('alert-title-input')
Expected: visible
Received: undefined

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByTestId('alert-title-input')
  - 

```

# Test source

```ts
  1  | import { test, expect } from '../../fixtures/test.fixtures';
  2  | import { AlertsPage } from '../../pages/AlertsPage.pom';
  3  | import { apiPost } from '../../helpers/api.helper';
  4  | 
  5  | test.describe('Alerts Management', () => {
  6  |   test('TC-PW-022: Alert list loads with data', async ({ adminPage }) => {
  7  |     const alertsPage = new AlertsPage(adminPage);
  8  |     await alertsPage.goto();
  9  |     // Either the list has items, or shows empty state
  10 |     await expect(alertsPage.alertList.or(adminPage.getByText(/no alerts/i).first())).toBeVisible({ timeout: 10000 });
  11 |   });
  12 | 
  13 |   test('TC-PW-023: New-alert broadcast composer is available to an admin', async ({ adminPage }) => {
  14 |     // There is no "open a dialog" step on this page — the composer is an
  15 |     // always-visible form for ADMIN / DMC_OFFICER. Confirm it renders with
  16 |     // its key fields ready for input.
  17 |     const alertsPage = new AlertsPage(adminPage);
  18 |     await alertsPage.goto();
  19 |     await expect(alertsPage.alertComposer).toBeVisible();
> 20 |     await expect(alertsPage.titleInput).toBeVisible();
     |                                         ^ Error: expect(locator).toBeVisible() failed
  21 |   });
  22 | 
  23 |   test('TC-PW-024: Alert form validation (empty title)', async ({ adminPage }) => {
  24 |     const alertsPage = new AlertsPage(adminPage);
  25 |     await alertsPage.goto();
  26 |     await alertsPage.submitButton.click();
  27 |     // HTML5 validation blocks submission while the required field is empty
  28 |     await expect(alertsPage.titleInput).toHaveAttribute('required', '');
  29 |   });
  30 | 
  31 |   test('TC-PW-025: Emergency alert banner appears via socket', async ({ adminPage, citizenPage, apiContext }) => {
  32 |     // Both admin and citizen should see the alert banner when an alert is created
  33 |     await adminPage.goto('/');
  34 |     await citizenPage.goto('/citizen-home');
  35 |     // Give the citizen page's socket.io client time to finish its handshake before we
  36 |     // broadcast — posting immediately after goto() can race the connection, especially
  37 |     // under the heavier load of a full multi-browser-project run.
  38 |     await citizenPage.waitForTimeout(1500);
  39 | 
  40 |     // Create an alert via API to trigger the socket event
  41 |     const alertData = {
  42 |       title: 'E2E Test Alert - Flood Warning',
  43 |       message: 'Playwright automated test alert',
  44 |       severity: 'HIGH',
  45 |       locations: ['All Island']
  46 |     };
  47 |     
  48 |     const response = await apiPost(apiContext, '/api/alerts', alertData, 'admin');
  49 |     expect(response.ok()).toBeTruthy();
  50 |     
  51 |     // Check if the global alert banner appears on the citizen page.
  52 |     // WebKit's socket.io handshake can lag noticeably behind Chromium/Firefox, so give it more room.
  53 |     const banner = citizenPage.locator('.fixed').filter({ hasText: 'E2E Test Alert' });
  54 |     await expect(banner.first()).toBeVisible({ timeout: 20000 });
  55 |   });
  56 | });
  57 | 
```