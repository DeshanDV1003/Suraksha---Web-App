# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-research\ai-research.spec.ts >> AI Research >> TC-PW-065: AI research page loads
- Location: e2e\ai-research\ai-research.spec.ts:4:7

# Error details

```
TimeoutError: page.goto: Timeout 45000ms exceeded.
Call log:
  - navigating to "http://localhost:4173/ai-research", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '../../fixtures/test.fixtures';
  2  | 
  3  | test.describe('AI Research', () => {
  4  |   test('TC-PW-065: AI research page loads', async ({ adminPage }) => {
> 5  |     await adminPage.goto('/ai-research');
     |                     ^ TimeoutError: page.goto: Timeout 45000ms exceeded.
  6  |     await expect(adminPage).toHaveURL(/.*ai-research/);
  7  |   });
  8  | 
  9  |   test('TC-PW-066: Graceful degradation when ML service is offline', async ({ adminPage }) => {
  10 |     await adminPage.goto('/ai-research');
  11 |     
  12 |     // It should either load data or show an error boundry / offline message, but NOT crash the whole app
  13 |     await expect(
  14 |       adminPage.locator('.bg-white, .grid').first()
  15 |       .or(adminPage.getByText(/offline|error|unavailable|failed/i).first())
  16 |       .or(adminPage.locator('.text-red-600').filter({ hasText: /crashed/i }))
  17 |     ).toBeVisible({ timeout: 15000 });
  18 |   });
  19 | });
  20 | 
```