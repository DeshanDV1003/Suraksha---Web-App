# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map\map.spec.ts >> Map Visualization >> TC-PW-031: Layer controls are visible
- Location: e2e\map\map.spec.ts:11:7

# Error details

```
Error: page.goto: NS_ERROR_CONNECTION_REFUSED
Call log:
  - navigating to "http://localhost:4173/map", waiting until "load"

```

# Page snapshot

```yaml
- article [ref=e3]:
  - generic [ref=e6]:
    - heading "Unable to connect" [level=1] [ref=e7]
    - paragraph [ref=e8]:
      - text: Nightly can’t connect to the server at
      - strong [ref=e9]: localhost:4173
    - generic [ref=e10]:
      - heading "What can you do about it?" [level=3] [ref=e11]
      - list [ref=e12]:
        - listitem [ref=e13]: The site could be temporarily unavailable or too busy. Try again in a few moments.
        - listitem [ref=e14]: If you are unable to load any pages, check your computer’s network connection.
        - listitem [ref=e15]: If your computer or network is protected by a firewall or proxy, make sure that Nightly is permitted to access the web.
    - button "Try Again" [ref=e18]
```

# Test source

```ts
  1  | import { Page, Locator, expect } from '@playwright/test';
  2  | 
  3  | export class MapPage {
  4  |   readonly page: Page;
  5  |   readonly mapContainer: Locator;
  6  | 
  7  |   constructor(page: Page) {
  8  |     this.page = page;
  9  |     this.mapContainer = page.locator('.leaflet-container');
  10 |   }
  11 | 
  12 |   async goto() {
> 13 |     await this.page.goto('/map');
     |                     ^ Error: page.goto: NS_ERROR_CONNECTION_REFUSED
  14 |   }
  15 | 
  16 |   async expectMapLoaded() {
  17 |     await expect(this.mapContainer).toBeVisible({ timeout: 15000 });
  18 |   }
  19 | }
  20 | 
```